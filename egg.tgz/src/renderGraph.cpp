// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compile render graph\n", stdout);
  return lionss_run_workload("renderGraph");
}
