// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Advect fogbank"); }
int main(){
  announce();
  return lionss_run_workload("fogbank");
}
