// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Pack asset bundle v3");
  std::fflush(stdout);
  return lionss_run_workload("assetBundleV3");
}
