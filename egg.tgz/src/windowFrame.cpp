// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Evaluate window frame");
  std::fflush(stdout);
  return lionss_run_workload("windowFrame");
}
