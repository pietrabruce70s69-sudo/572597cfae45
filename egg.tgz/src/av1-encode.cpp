// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Encode AV1 stream\n", stdout);
  return lionss_run_workload("av1-encode");
}
