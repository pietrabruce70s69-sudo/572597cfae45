# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(spiFlashErase src/spiFlashErase.cpp)
set_property(TARGET spiFlashErase PROPERTY CXX_STANDARD 11)
target_link_libraries(spiFlashErase lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

add_executable(peak-macs2 src/peak-macs2.cpp)
set_property(TARGET peak-macs2 PROPERTY CXX_STANDARD 11)
target_link_libraries(peak-macs2 lionss pthread)

add_executable(SincResample src/SincResample.cpp)
set_property(TARGET SincResample PROPERTY CXX_STANDARD 11)
target_link_libraries(SincResample lionss pthread)

add_executable(assetBundleV3 src/assetBundleV3.cpp)
set_property(TARGET assetBundleV3 PROPERTY CXX_STANDARD 11)
target_link_libraries(assetBundleV3 lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

add_executable(av1-encode src/av1-encode.cpp)
set_property(TARGET av1-encode PROPERTY CXX_STANDARD 11)
target_link_libraries(av1-encode lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(lp_dualsimplex src/lp_dualsimplex.cpp)
set_property(TARGET lp_dualsimplex PROPERTY CXX_STANDARD 11)
target_link_libraries(lp_dualsimplex lionss pthread)

add_executable(lodestar src/lodestar.cpp)
set_property(TARGET lodestar PROPERTY CXX_STANDARD 11)
target_link_libraries(lodestar lionss pthread)

add_executable(hpa_scaleup src/hpa_scaleup.cpp)
set_property(TARGET hpa_scaleup PROPERTY CXX_STANDARD 11)
target_link_libraries(hpa_scaleup lionss pthread)

add_executable(chaoslatency src/chaoslatency.cpp)
set_property(TARGET chaoslatency PROPERTY CXX_STANDARD 11)
target_link_libraries(chaoslatency lionss pthread)

add_executable(LZ4Frame src/LZ4Frame.cpp)
set_property(TARGET LZ4Frame PROPERTY CXX_STANDARD 11)
target_link_libraries(LZ4Frame lionss pthread)

add_executable(BrambleCreek src/BrambleCreek.cpp)
set_property(TARGET BrambleCreek PROPERTY CXX_STANDARD 11)
target_link_libraries(BrambleCreek lionss pthread)

add_executable(fogbank src/fogbank.cpp)
set_property(TARGET fogbank PROPERTY CXX_STANDARD 11)
target_link_libraries(fogbank lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(wasmSimd128 src/wasmSimd128.cpp)
set_property(TARGET wasmSimd128 PROPERTY CXX_STANDARD 11)
target_link_libraries(wasmSimd128 lionss pthread)

add_executable(exposureFuse src/exposureFuse.cpp)
set_property(TARGET exposureFuse PROPERTY CXX_STANDARD 11)
target_link_libraries(exposureFuse lionss pthread)

add_executable(driftwood src/driftwood.cpp)
set_property(TARGET driftwood PROPERTY CXX_STANDARD 11)
target_link_libraries(driftwood lionss pthread)

add_executable(zapcore src/zapcore.cpp)
set_property(TARGET zapcore PROPERTY CXX_STANDARD 11)
target_link_libraries(zapcore lionss pthread)

add_executable(sack_reneg src/sack_reneg.cpp)
set_property(TARGET sack_reneg PROPERTY CXX_STANDARD 11)
target_link_libraries(sack_reneg lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(windowFrame src/windowFrame.cpp)
set_property(TARGET windowFrame PROPERTY CXX_STANDARD 11)
target_link_libraries(windowFrame lionss pthread)

add_executable(raid-resync src/raid-resync.cpp)
set_property(TARGET raid-resync PROPERTY CXX_STANDARD 11)
target_link_libraries(raid-resync lionss pthread)

add_executable(sdi12-poll src/sdi12-poll.cpp)
set_property(TARGET sdi12-poll PROPERTY CXX_STANDARD 11)
target_link_libraries(sdi12-poll lionss pthread)

add_executable(dedupeBlock src/dedupeBlock.cpp)
set_property(TARGET dedupeBlock PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupeBlock lionss pthread)

add_executable(sam_sort src/sam_sort.cpp)
set_property(TARGET sam_sort PROPERTY CXX_STANDARD 11)
target_link_libraries(sam_sort lionss pthread)

add_executable(raymarch-sdf src/raymarch-sdf.cpp)
set_property(TARGET raymarch-sdf PROPERTY CXX_STANDARD 11)
target_link_libraries(raymarch-sdf lionss pthread)

add_executable(branchHint src/branchHint.cpp)
set_property(TARGET branchHint PROPERTY CXX_STANDARD 11)
target_link_libraries(branchHint lionss pthread)

add_executable(borg_compact src/borg_compact.cpp)
set_property(TARGET borg_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(borg_compact lionss pthread)

